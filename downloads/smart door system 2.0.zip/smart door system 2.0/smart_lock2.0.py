import cv2
import face_recognition
import os
import serial
import time
import threading
import requests
from datetime import datetime
import numpy as np

# --- إعدادات تيليجرام ---
BOT_TOKEN = "8479019573:AAFVK0wF2Eo5JGiOzQnQXzAH5e0oZOnhbO0"
CHAT_ID = "-1002839644300"

def send_telegram_alert(msg):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": msg}
    try:
        requests.post(url, data=data)
        print("Telegram alert sent!")
    except Exception as e:
        print("Error sending telegram:", e)

# --- ألوان فخمة BGR ---
COLORS = {
    "Manager": (65, 105, 225),      # royal blue
    "Employee": (0, 128, 0),        # luxury green
    "Unknown": (0, 0, 255),         # luxury red
}

# --- تحميل وجوه من المجلدات ---
def load_faces_from_folder(folder_path, role):
    encodings = []
    names = []
    roles = []
    for filename in os.listdir(folder_path):
        if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
            path = os.path.join(folder_path, filename)
            image = face_recognition.load_image_file(path)
            encs = face_recognition.face_encodings(image)
            if encs:
                encodings.append(encs[0])
                name = os.path.splitext(filename)[0]
                names.append(name)
                roles.append(role)
                print(f"Loaded {role}: {name}")
    return encodings, names, roles

print("Loading faces...")
mgr_encodings, mgr_names, mgr_roles = load_faces_from_folder("faces/manager", "Manager")
emp_encodings, emp_names, emp_roles = load_faces_from_folder("faces/employee", "Employee")

known_encodings = mgr_encodings + emp_encodings
known_names = mgr_names + emp_names
known_roles = mgr_roles + emp_roles

# --- إعداد Serial مع Arduino ---
try:
    ser = serial.Serial('COM3', 9600, timeout=1)
    time.sleep(2)
    print("Connected to Arduino serial")
except Exception as e:
    print("Failed to connect to Arduino:", e)
    ser = None

obstacle_present = False
system_locked = False
last_lock_time = 0
lock_cooldown = 10  # ثانية cooldown بين عمليات القفل لتجنب الإرسال المتكرر

def read_serial():
    global obstacle_present, system_locked
    while True:
        if ser and ser.in_waiting:
            line = ser.readline().decode(errors='ignore').strip()
            if line == "OBSTACLE_DETECTED":
                obstacle_present = True
                print("[Arduino] Obstacle detected")
            elif line == "NO_OBSTACLE":
                obstacle_present = False
                print("[Arduino] No obstacle")
            elif line == "SYSTEM_LOCKED":
                system_locked = True
                print("[Arduino] System locked")
            elif line == "SYSTEM_UNLOCKED":
                system_locked = False
                print("[Arduino] System unlocked")
        time.sleep(0.1)

if ser:
    threading.Thread(target=read_serial, daemon=True).start()

def lock_system():
    global system_locked, last_lock_time
    now = time.time()
    if ser and not system_locked and (now - last_lock_time) > lock_cooldown:
        ser.write(b"LOCK_SYSTEM\n")
        system_locked = True
        last_lock_time = now
        alert_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        alert_msg = (f"🚨 Security Alert 🚨\n"
                     f"Unauthorized access attempt detected at {alert_time}.\n"
                     f"System locked automatically.")
        send_telegram_alert(alert_msg)
        print("System locked and Telegram alert sent.")

# --- كاميرا + التعرف على الوجوه ---
cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        print("Failed to capture frame")
        break

    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
    rgb_small_frame = small_frame[:, :, ::-1]

    if obstacle_present and not system_locked:
        face_locations = face_recognition.face_locations(rgb_small_frame)
        face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

        detected_roles = set()

        for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            matches = face_recognition.compare_faces(known_encodings, face_encoding, tolerance=0.45)
            name = "Unknown"
            role = "Unknown"
            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            if len(face_distances) > 0:
                best_index = np.argmin(face_distances)
                if matches[best_index]:
                    name = known_names[best_index]
                    role = known_roles[best_index]

            detected_roles.add(role)

            # إحداثيات تصغير الحجم
            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            color = COLORS.get(role, COLORS["Unknown"])
            cv2.rectangle(frame, (left, top), (right, bottom), color, 3)
            label = f"{name} ({role})"
            cv2.putText(frame, label, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.75, color, 2)

        # تحقق من صلاحيات المخالفين أو مجهولين
        if "Unknown" in detected_roles:
            print("Unknown face detected! Locking system...")
            lock_system()
        # ممكن هنا تضيف قواعد مثلاً منع موظف من صلاحية مدير وهكذا
        # مثال: لو فيه مدير وموظف مع بعض، أو موظف يحاول صلاحية مدير... إلخ
        # أو لو عندك قائمة تحكم ممكن تضيفها

    else:
        status_text = "Waiting for obstacle or system unlocked..."
        cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (100, 100, 100), 2)

    cv2.imshow("Smart Door Access Control", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

import serial
import threading
import tkinter as tk
from tkinter import messagebox
import cv2
from PIL import Image, ImageTk
import time
ser = serial.Serial('COM3', 9600)  
obstacle_present = False
last_motion_time = 0
admin_mode = False
emergency_open = False
system_locked = False
camera_active = False
manual_override = False
cap = None
OBSTACLE_TIMEOUT = 2
def send_command(cmd):
    ser.write((cmd + "\n").encode())
def read_serial():
    global obstacle_present, last_motion_time
    global admin_mode, emergency_open, system_locked
    while True:
        try:
            line = ser.readline().decode().strip()
            print("[ARDUINO]:", line)
            if line == "OBSTACLE_DETECTED":
                obstacle_present = True
                last_motion_time = time.time()
                update_ui()
            elif line == "NO_OBSTACLE":
                last_motion_time = time.time()
                obstacle_present = False
                update_ui()
            elif line == "ADMIN_OPTIONS":
                toggle_admin_mode()
            elif line == "EXIT_ADMIN":
                admin_mode = False
                update_ui()
            elif line == "SYSTEM_LOCKED":
                system_locked = True
                update_ui()
            elif line == "SYSTEM_UNLOCKED":
                system_locked = False
                update_ui()
            elif line == "EMERGENCY_OPEN":
                emergency_open = True
                update_ui()
            elif line == "EMERGENCY_CLOSED":
                emergency_open = False
                update_ui()
        except Exception as e:
            print("Serial Error:", e)
def update_ui():
    cam_status.config(text="Camera: ON" if camera_active else "Camera: OFF",
                      fg="green" if camera_active else "red")
    if emergency_open:
        status_label.config(text="EMG DOOR OPEN", fg="orange")
    elif admin_mode:
        status_label.config(text="ADMIN ON", fg="blue")
    elif system_locked:
        status_label.config(text="LOCKED", fg="red")
    else:
        status_label.config(text="ACTIVE", fg="green")
    if admin_mode:
        admin_frame.pack(pady=10)
    else:
        admin_frame.pack_forget()
    if obstacle_present:
        cam_button.pack(pady=5)
    else:
        cam_button.pack_forget()
def start_camera():
    global cap, camera_active
    if cap is None or not cap.isOpened():
        cap = cv2.VideoCapture(0)
    camera_active = True
    update_ui()
    update_cam()
def update_cam():
    global camera_active, cap
    if camera_active and cap and cap.isOpened():
        ret, frame = cap.read()
        if ret:
            frame = cv2.resize(frame, (350, 250))
            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            imgtk = ImageTk.PhotoImage(image=img)
            camera_canvas.imgtk = imgtk
            camera_canvas.config(image=imgtk)
            root.after(100, update_cam)
        else:
            cap.release()
            cap = cv2.VideoCapture(0)
            root.after(500, update_cam)
    else:
        camera_canvas.config(image='')
def stop_camera():
    global cap, camera_active
    if cap and cap.isOpened():
        cap.release()
    cap = None
    camera_active = False
    camera_canvas.config(image='')
    update_ui()
def toggle_admin_mode():
    global admin_mode
    admin_mode = not admin_mode
    update_ui()
def attempt_password():
    if not obstacle_present or system_locked or admin_mode:
        return
    password = password_entry.get()
    if len(password) == 4 and password.isdigit():
        send_command(password)
        password_entry.delete(0, tk.END)
def set_password():
    new_pass = password_entry.get()
    if len(new_pass) == 4 and new_pass.isdigit():
        send_command(f"SET:{new_pass}")
        password_entry.delete(0, tk.END)
    else:
        messagebox.showerror("Error", "Password must be 4 digits")
def toggle_lock():
    send_command("UNLOCK_SYSTEM" if system_locked else "LOCK_SYSTEM")
def open_door():
    send_command("OPEN_DOOR")
def joystick_control(val):
    send_command(f"JOY:{val}")
def manual_camera_toggle():
    global manual_override
    if obstacle_present:
        if camera_active:
            stop_camera()
            manual_override = False
        else:
            manual_override = True
            start_camera()
root = tk.Tk()
root.title("Smart Door Lock")
root.geometry("800x600")
root.configure(bg='white')  # واجهة بيضاء
top_frame = tk.Frame(root, bg='white')
top_frame.pack(pady=10)
status_label = tk.Label(top_frame, text="System Active", font=("Arial", 18), fg="green", bg='white')
status_label.pack()
cam_status = tk.Label(top_frame, text="Camera: OFF", font=("Arial", 14), fg="red", bg='white')
cam_status.pack()
cam_button = tk.Button(top_frame, text="Start/Stop Camera", font=("Arial", 12),
                       command=manual_camera_toggle, bg="black", fg="white")
camera_frame = tk.Frame(root, bg='white')
camera_frame.pack()
camera_canvas = tk.Label(camera_frame, bg='white')
camera_canvas.pack()
entry_frame = tk.Frame(root, bg='white')
entry_frame.pack(pady=10)
password_entry = tk.Entry(entry_frame, font=("Arial", 18), width=10, justify="center")
password_entry.pack(pady=5)
submit_btn = tk.Button(entry_frame, text="Enter Password", font=("Arial", 14), command=attempt_password,
                       bg="black", fg="white", width=20)
submit_btn.pack(pady=5)
admin_frame = tk.Frame(root, bg='white')
tk.Label(admin_frame, text="Admin Controls", font=("Arial", 16), bg='white', fg='black').pack()
tk.Button(admin_frame, text="Open Door", command=open_door,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Button(admin_frame, text="Set New Password", command=set_password,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Button(admin_frame, text="Lock/Unlock System", command=toggle_lock,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Label(admin_frame, text="Servo Control", font=("Arial", 12), bg='white', fg='black').pack()
angle_slider = tk.Scale(admin_frame, from_=0, to=90, orient=tk.HORIZONTAL, command=joystick_control,
                        bg='white', fg='black', troughcolor='skyblue', length=300)
angle_slider.set(0)
angle_slider.pack(pady=5)
threading.Thread(target=read_serial, daemon=True).start()
update_ui()
root.mainloop()
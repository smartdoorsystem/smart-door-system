import serial
import threading
import tkinter as tk
from tkinter import messagebox
import cv2
from PIL import Image, ImageTk
import time
import requests
from datetime import datetime
import face_recognition
import os
import numpy as np

# معلومات بوت تليجرام
BOT_TOKEN = "8325912903:AAG_UCYMaeVt98QTf5drDJGdOzDXzDXUzck"
CHAT_ID = "-1002839644300"

def send_telegram_alert(msg):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {"chat_id": CHAT_ID, "text": msg}
    try:
        requests.post(url, data=data)
        print("Telegram alert sent!")
    except Exception as e:
        print("Error sending telegram:", e)

# فتح المنفذ التسلسلي للأردوينو (غيّر COM3 حسب جهازك)
try:
    ser = serial.Serial('COM3', 9600, timeout=1)
except Exception as e:
    print("Error opening serial port:", e)
    ser = None

# حالة النظام والمتغيرات
obstacle_present = False
last_motion_time = 0
admin_mode = False
emergency_open = False
system_locked = False
camera_active = False
manual_override = False
cap = None
OBSTACLE_TIMEOUT = 2

# تحميل وجوه المديرين والموظفين مع الأسماء الحقيقية (غير آخر حرف كما طلبت)
known_face_encodings = []
known_face_names = []

def load_known_faces():
    # مدير - نقرأ ملفات الصور من مجلد manager ونحذف آخر حرف من الاسم
    manager_path = r"C:\Users\MSI CYBORG\faces\manager"
    for filename in os.listdir(manager_path):
        if filename.endswith((".jpg", ".png")):
            img = face_recognition.load_image_file(os.path.join(manager_path, filename))
            encodings = face_recognition.face_encodings(img)
            if encodings:
                known_face_encodings.append(encodings[0])
                # نحصل على الاسم من اسم الملف بدون الامتداد ونحذف آخر حرف
                name = os.path.splitext(filename)[0][:-1]
                known_face_names.append((name, "Manager"))

    # موظف - من مجلد employee
    employee_path = r"C:\Users\MSI CYBORG\faces\employee"
    for filename in os.listdir(employee_path):
        if filename.endswith((".jpg", ".png")):
            img = face_recognition.load_image_file(os.path.join(employee_path, filename))
            encodings = face_recognition.face_encodings(img)
            if encodings:
                known_face_encodings.append(encodings[0])
                name = os.path.splitext(filename)[0][:-1]
                known_face_names.append((name, "Employee"))

load_known_faces()

unknown_detected = False

def send_command(cmd):
    if ser and ser.is_open:
        print(f"[SENDING TO ARDUINO]: {cmd}")
        ser.write((cmd + "\n").encode())

def update_ui():
    global camera_active, obstacle_present, admin_mode, emergency_open, system_locked
    cam_status.config(text="Camera: ON" if camera_active else "Camera: OFF",
                      fg="green" if camera_active else "red")
    if emergency_open:
        status_label.config(text="EMERGENCY DOOR ON", fg="red")
    elif admin_mode:
        status_label.config(text="THE ADMINISTRATOR ON", fg="blue")
    elif system_locked:
        status_label.config(text="SYSTEM LOCKED", fg="brown")
    else:
        status_label.config(text="ACTIVE", fg="green")
    if admin_mode:
        admin_frame.pack(pady=10)
    else:
        admin_frame.pack_forget()
    if obstacle_present:
        cam_button.pack(pady=5)
    else:
        cam_button.pack_forget()

def start_camera():
    global cap, camera_active, unknown_detected
    if cap is None or not cap.isOpened():
        cap = cv2.VideoCapture(0)
    camera_active = True
    unknown_detected = False
    update_ui()
    update_cam()

def update_cam():
    global camera_active, cap, unknown_detected, system_locked

    if camera_active and cap and cap.isOpened():
        ret, frame = cap.read()
        if ret:
            frame = cv2.resize(frame, (450, 250))
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            face_display_info = []
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=0.5)
                name = "Unknown"
                role = ""
                face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                if len(face_distances) > 0:
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name, role = known_face_names[best_match_index]
                else:
                    role = ""
                face_display_info.append((name, role))

            # لو اكتشف Unknown و النظام مفتوح، يقفل النظام ويرسل تنبيه
            if any(name == "Unknown" for name, _ in face_display_info) and not system_locked:
                unknown_detected = True
                print("Unknown face detected! Locking system...")
                send_command("LOCK_SYSTEM")
                now = datetime.now().strftime("%Y/%m/%d  %H:%M:%S")
                send_telegram_alert(f"🚨 Unknown face detected at {now}.\nSystem locked immediately!")
                system_locked = True
                update_ui()

            for (top, right, bottom, left), (name, role) in zip(face_locations, face_display_info):
                if name == "Unknown":
                    color = (0, 0, 255)  # أحمر
                    display_text1 = name
                    display_text2 = ""
                elif role == "Manager":
                    color = (255, 0, 0)  # أزرق ملكي
                    display_text1 = name
                    display_text2 = "Manager"
                elif role == "Employee":
                    color = (0, 255, 0)  # أخضر فخم
                    display_text1 = name
                    display_text2 = "Employee"
                else:
                    color = (255, 255, 255)  # أبيض افتراضي
                    display_text1 = name
                    display_text2 = role

                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                cv2.rectangle(frame, (left, bottom - 40), (right, bottom), color, cv2.FILLED)
                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, display_text1, (left + 6, bottom - 26), font, 0.5, (255, 255, 255), 1)
                if display_text2:
                    cv2.putText(frame, display_text2, (left + 6, bottom - 8), font, 0.5, (255, 255, 255), 1)

            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            imgtk = ImageTk.PhotoImage(image=img)
            camera_canvas.imgtk = imgtk
            camera_canvas.config(image=imgtk)

            root.after(100, update_cam)
        else:
            cap.release()
            cap = cv2.VideoCapture(0)
            root.after(500, update_cam)
    else:
        camera_canvas.config(image='')

def stop_camera():
    global cap, camera_active, unknown_detected
    if cap and cap.isOpened():
        cap.release()
    cap = None
    camera_active = False
    unknown_detected = False
    camera_canvas.config(image='')
    update_ui()

def toggle_admin_mode():
    global admin_mode
    admin_mode = not admin_mode
    update_ui()

def attempt_password():
    global obstacle_present, system_locked, admin_mode
    if not obstacle_present or system_locked or admin_mode:
        return
    password = password_entry.get()
    if len(password) == 4 and password.isdigit():
        # منع الموظف من الدخول كمدير عبر كلمة السر
        if password == '9231' and not admin_mode:
            now = datetime.now().strftime("%Y/%m/%d  %H:%M:%S")
            send_telegram_alert(f"⚠️ Warning: Employee tried to enter Manager password at {now}!\nSystem locked.")
            send_command("LOCK_SYSTEM")
            password_entry.delete(0, tk.END)
            return
        send_command(password)
        password_entry.delete(0, tk.END)

def set_password():
    new_pass = password_entry.get()
    if len(new_pass) == 4 and new_pass.isdigit():
        send_command(f"SET:{new_pass}")
        password_entry.delete(0, tk.END)
    else:
        messagebox.showerror("Error", "Password must be 4 digits")

def toggle_lock():
    global system_locked
    if system_locked:
        send_command("UNLOCK_SYSTEM")
    else:
        send_command("LOCK_SYSTEM")

def open_door():
    send_command("OPEN_DOOR")

def joystick_control(val):
    send_command(f"JOY:{val}")

def manual_camera_toggle():
    global manual_override, obstacle_present, camera_active
    if obstacle_present:
        if camera_active:
            stop_camera()
            manual_override = False
        else:
            manual_override = True
            start_camera()

def read_serial():
    global obstacle_present, last_motion_time
    global admin_mode, emergency_open, system_locked
    global camera_active, manual_override

    while True:
        if ser is None:
            time.sleep(1)
            continue
        try:
            line = ser.readline().decode(errors='ignore').strip()
            if not line:
                time.sleep(0.05)
                continue
            print("[ARDUINO]:", line)
            changed = False

            if line == "OBSTACLE_DETECTED":
                if not obstacle_present:
                    obstacle_present = True
                    last_motion_time = time.time()
                    changed = True

            elif line == "NO_OBSTACLE":
                if obstacle_present:
                    obstacle_present = False
                    last_motion_time = time.time()
                    changed = True
                    if camera_active and not manual_override:
                        root.after(0, stop_camera)

            elif line == "ADMIN_OPTIONS":
                if not admin_mode:
                    admin_mode = True
                    changed = True

            elif line == "EXIT_ADMIN":
                if admin_mode:
                    admin_mode = False
                    changed = True

            elif line == "SYSTEM_LOCKED":
                if not system_locked:
                    system_locked = True
                    changed = True

            elif line == "SYSTEM_UNLOCKED":
                if system_locked:
                    system_locked = False
                    changed = True

            elif line == "EMERGENCY_OPEN":
                if not emergency_open:
                    emergency_open = True
                    changed = True

            elif line == "EMERGENCY_CLOSED":
                if emergency_open:
                    emergency_open = False
                    changed = True

            elif line == "PASSWORD_UPDATED":
                root.after(0, lambda: messagebox.showinfo("Info", "Password changed successfully"))

            elif line == "INVALID_PASS":
                root.after(0, lambda: messagebox.showerror("Error", "Invalid password format"))

            elif line.startswith("ALERT:"):
                now = datetime.now().strftime("%Y/%m/%d  %H:%M:%S")
                if "PASSWORD" in line:
                    msg = (
                        "🚨 Security Alert 🚨\n"
                        "Dear Administrator\n"
                        f"At {now}\nthe system has detected 3 consecutive (wrong password) attempts.\n"
                        "Please verify the identity of the person."
                    )
                elif "CARD" in line:
                    msg = (
                        "🚨 Security Alert 🚨\n"
                        "to the Administrator\n"
                        f"At {now}\nthe system has detected 3 consecutive (unauthorized card) attempts.\n"
                        "Please verify the identity of the person."
                    )
                else:
                    msg = f"🚨 Alert triggered at {now}\nunknown reason."
                send_telegram_alert(msg)

            if changed:
                root.after(0, update_ui)
        except Exception as e:
            print("Serial Error:", e)
            time.sleep(0.5)

def check_telegram_commands():
    last_update_id = None
    print("[TELEGRAM] Listening for commands...")
    while True:
        try:
            url = f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"
            if last_update_id:
                url += f"?offset={last_update_id + 1}"

            response = requests.get(url)
            if response.status_code == 200:
                data = response.json()
                for update in data["result"]:
                    last_update_id = update["update_id"]
                    if "message" in update:
                        message = update["message"]
                        chat_id = str(message["chat"]["id"])
                        text = message.get("text", "").strip().lower()

                        print(f"[CHAT_ID]: {chat_id} | [TEXT]: {text}")

                        if chat_id == CHAT_ID:
                            now = datetime.now().strftime("%Y/%m/%d  %H:%M:%S")
                            if text == "/open@smart_door_system_bot":
                                send_command("OPEN_DOOR")
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe door was opend by you.\nyour smart door system bot is always here to help you.")
                                system_locked = False
                                root.after(0, update_ui)
                            elif text == "/lock@smart_door_system_bot":
                                send_command("LOCK_SYSTEM")
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe smart door system was locked by you.\nyour smart door system bot is always here to help you.")
                                system_locked = True
                                root.after(0, update_ui)
                            elif text == "/unlock@smart_door_system_bot":
                                send_command("UNLOCK_SYSTEM")  
                                system_locked = False        
                                root.after(0, update_ui)
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe smart door system was unlocked by you.\nyour smart door system bot is always here to help you.")
                            elif text == "/penalty@smart_door_system_bot":
                                send_command("PENALTY")  # تأكد أن الأردوينو يستقبل هذا الأمر لفك القفل
                                system_locked = False        # تحديث الحالة محليًا
                                root.after(0, update_ui)
                                send_telegram_alert(f"to the administrator\nAt {now}\nA penalty was triggered by you.\nyour smart door system bot is always here to help you.")
                            elif text == "/buzz@smart_door_system_bot":
                                send_command("BUZZ")  # تأكد أن الأردوينو يستقبل هذا الأمر لفك القفل
                                system_locked = False        # تحديث الحالة محليًا
                                root.after(0, update_ui)
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe smart door buzzer was activated by you.\nyour smart door system bot is always here to help you.")  
                            elif text == "/emg_open@smart_door_system_bot":
                                send_command("EMERGENCY_OPEN")  # تأكد أن الأردوينو يستقبل هذا الأمر لفك القفل
                                system_locked = False        # تحديث الحالة محليًا
                                root.after(0, update_ui)
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe smart door system emg door was opened by you.\nyour smart door system bot is always here to help you.") 
                            elif text == "/emg_close@smart_door_system_bot":
                                send_command("EMERGENCY_CLOSE")  # تأكد أن الأردوينو يستقبل هذا الأمر لفك القفل
                                system_locked = False        # تحديث الحالة محليًا
                                root.after(0, update_ui)
                                send_telegram_alert(f"to the administrator\nAt {now}\nthe smart door system emg door was closed by you.\nyour smart door system bot is always here to help you.") 
            time.sleep(2)
        except Exception as e:
            print("[TELEGRAM ERROR]:", e)
            time.sleep(5)

# === واجهة المستخدم ===

root = tk.Tk()
root.title("Smart Door system")
root.geometry("800x600")
root.configure(bg='white')

top_frame = tk.Frame(root, bg='white')
top_frame.pack(pady=10)

status_label = tk.Label(top_frame, text="System Active", font=("Arial", 18), fg="green", bg='white')
status_label.pack()

cam_status = tk.Label(top_frame, text="Camera: OFF", font=("Arial", 14), fg="red", bg='white')
cam_status.pack()

# زر التحكم بالكاميرا
cam_button = tk.Button(top_frame, text="Start/Stop Camera", font=("Arial", 12),
                       command=manual_camera_toggle, bg="black", fg="white")

camera_frame = tk.Frame(root, bg='white')
camera_frame.pack()
camera_canvas = tk.Label(camera_frame, bg='white')
camera_canvas.pack()

entry_frame = tk.Frame(root, bg='white')
entry_frame.pack(pady=10)

password_entry = tk.Entry(entry_frame, font=("Arial", 18), width=10, justify="center")
password_entry.pack(pady=5)

submit_btn = tk.Button(entry_frame, text="Enter Password", font=("Arial", 14), command=attempt_password,
                       bg="black", fg="white", width=20)
submit_btn.pack(pady=5)

admin_frame = tk.Frame(root, bg='white')
tk.Label(admin_frame, text="admin options", font=("Arial", 16), bg='white', fg='black').pack()
tk.Button(admin_frame, text="Open Door", command=open_door,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Button(admin_frame, text="Set New Password", command=set_password,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Button(admin_frame, text="Lock/Unlock System", command=toggle_lock,
          bg="black", fg="white", width=25).pack(pady=3)
tk.Label(admin_frame, text="door slider", font=("Arial", 12), bg='white', fg='black').pack()
angle_slider = tk.Scale(admin_frame, from_=0, to=180, orient=tk.HORIZONTAL, command=joystick_control,
                        bg='white', fg='black', troughcolor='skyblue', length=300)
angle_slider.set(0)
angle_slider.pack(pady=5)

# تشغيل الخيوط الخاصة بالقراءة من الأردوينو و التليجرام
threading.Thread(target=read_serial, daemon=True).start()
threading.Thread(target=check_telegram_commands, daemon=True).start()

update_ui()
root.mainloop()
